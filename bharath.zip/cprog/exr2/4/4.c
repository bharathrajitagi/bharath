#include<stdio.h>
void main()
{
	float  kmph,mps;
	printf("enter the speed in kmph\n");
	scanf("%f", &kmph);
	
	mps = (5.0/18) * kmph;
	
	printf("speed in mps is %f\n", mps);

}