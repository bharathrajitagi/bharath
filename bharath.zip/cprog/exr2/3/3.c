#include<stdio.h>

void main()
{
	int pow, lu_eff, lu_fl;
	printf("enter the power in watts\n");
	scanf("%d",&pow);
	printf("enter the luminous efficiency\n");
	scanf("%d",&lu_eff);
	
	lu_fl = pow * lu_eff;
	
	printf("luminous flux is %d\n",lu_fl);
}