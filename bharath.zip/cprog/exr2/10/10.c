#include<stdio.h>
void main()
{
	char ch;
	printf("enter the alphabet\n");;
	scanf("%c",&ch);
	
	if('a'<=ch && 'z'>=ch )
		printf("upper case of %c is %c\n",ch,ch-32 );
	else if('A'<=ch && 'Z'>=ch)
		printf("lower case of %c is %c\n",ch,ch+32 );
	
   }