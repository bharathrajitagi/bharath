#include<stdio.h>
 
int main() {
 
   int rad;
   float Pi = 3.14, area, ci;
 
   printf("\nEnter radius of circle: ");
   scanf("%d", &rad);
 
   area = Pi * rad * rad;
   printf("\nArea of circle : %f ", area);
 
   ci = 2 * Pi * rad;
   printf("\nCircumference : %f \n", ci);
 
   return 0;
}