#include<stdio.h>

void main()
{
int n;
double sum=0;
printf("enter the series length: \n");
scanf("%d", &n);

    int fact = 1;
    for (int i = 1; i <= n; i++)
    {
       fact *= i;         // Update factorial
       sum += 1.0/fact;   // Update series sum
    }
    printf("the sum is %lf",sum);
}