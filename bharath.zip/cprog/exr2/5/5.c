#include<stdio.h>
void main()
{
	float iv,fv,t_d,t_s,d;

	printf("enter the initial and final velocity of car\n");
	scanf("%f%f",&iv,&fv);
	printf("enter the distance between car and truck\n");
	scanf("%f",&d);
	printf("enter the time delay after which the truck starts\n");
	scanf("%f",&t_s);

	t_d = (2*d)/(iv+fv);
	
	printf(" the time delay is %f\n",t_d);
	
	if(t_d<t_s)
		printf("car will hit the truck\n");
	else
		printf("car doesnt hit the truck\n");

}