#include<stdio.h>
void main()
{
  float j, k, s;
 printf(" Enter the energy to convert :");
 scanf("%f",&j);
 printf(" Enter the time to convert:  ");
 scanf("%f", &s);
 
 k = (j)/(1000* s);
 
 printf("Energy in Kwh:  %f  ", k);
}

